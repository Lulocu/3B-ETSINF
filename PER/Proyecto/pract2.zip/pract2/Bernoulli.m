% Computes the error rate of 
% of the test set Y with respect to training set X
% X  is a n x d training data matrix 
% xl is a n x 1 training label vector 
% Y is a m x d test data matrix
% yl is a m x 1 test label vector 
% epsilons is a vector of values to use in Lplace
function [etr,edv]= bernoulli(Xtr,xltr,Xdv,xldvl,epsilons)

%Umbralizar datos

%Estimar probabilidad a priori

%Estimar función densidad

%Clasificador en forma de producto escalar

end

% percentage of error
err = mean(yl!=classification')*100; %dudas de si dejar

end

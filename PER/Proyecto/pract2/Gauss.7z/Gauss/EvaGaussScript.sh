./gauss-eva.m ../../MNIST/train-images-idx3-ubyte.mat.gz ../../MNIST/train-labels-idx1-ubyte.mat.gz ../../MNIST/t10k-images-idx3-ubyte.mat.gz ../../MNIST/t10k-labels-idx1-ubyte.mat.gz 1e-4

./gaussian-exp.m ../../MNIST/train-images-idx3-ubyte.mat.gz ../../MNIST/train-labels-idx1-ubyte.mat.gz "[1E-9 1E-8 1E-7 1E-6 1E-5 1E-4 1E-3 1E-2 1E-1 9E-1]" 90 10

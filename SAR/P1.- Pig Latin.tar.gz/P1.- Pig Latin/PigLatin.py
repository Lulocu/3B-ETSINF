#!/usr/bin/env python
#! -*- encoding: utf8 -*-

# 1.- Pig Latin
#diff para comparar
import sys
import re


class Translator():


    def __init__(self, punt=None):
        """
        Constructor de la clase Translator

        :param punt(opcional): una cadena con los signos de puntuación
                                que se deben respetar
        :return: el objeto de tipo Translator
        """
        if punt is None:
            self.re = re.compile("(\w+)([.,;?!]*)")
        else:
            self.re = re.compile("(\w+)(["+punt+"]*)")

    def translate_word(self, word):
        """
        Este método recibe una palabra en inglés y la traduce a Pig Latin

        :param word: la palabra que se debe pasar a Pig Latin
        :return: la palabra traducida
        """

        #sustituir
        #new_word = word
        #isupper -> todo mayus?
        #word[0].isupper() empieza mayus?
        #wordc = word[0].upper + word[1:].lower() palabra empieza por mayus
        #empieza vocal if word[0] in "aeiouy"

        if not esLetra(word[0])
            return word

            #mirar si empiezaconsonante
        new_word = word + 'yay'
        #newWord, symbol = 
        return new_word

    def translate_sentence(self, sentence):
        """
        Este método recibe una frase en inglés y la traduce a Pig Latin

        :param sentence: la frase que se debe pasar a Pig Latin
        :return: la frase traducida
        """

        # sustituir
        # new_sentence = sentence
        traducciones = []
        for word in sentence.split()
            newWord = self.translate_word
            traducciones.append(newWord)
        new_sentence = ' '.join(traducciones)
        return new_sentence

    def translate_file(self, filename):
        """
        Este método recibe un fichero y crea otro con su tradución a Pig Latin

        :param filename: el nombre del fichero que se debe traducir
        :return: True / False 
        """
        #manejador = open(fichero,modo), para crear igual modo escritura (w)
        #iterador sobre el manejador

        fh = open('filename.txt')
        fh2 = open('res','w')
        for line in fh:
            linia = self.translate_sentence(line)
            fh2.write(linia)
        fh2.close()

        # rellenar
def esVocal(l):
    return l in 'aeiouy'
def esLetra(l)
    return l in 'qwertyuiopasdfghjklñzxcvbnmç'

if __name__ == "__main__":
    if len(sys.argv) > 2:
        print('Syntax: python %s [filename]' % sys.argv[0])
        exit
    else:
        t = Translator()
        if len(sys.argv) == 2:
            t.translate_file(sys.argv[1])
        else:
            while True:
                sentence = input("ENGLISH: ")
                if len(sentence) < 2:
                    break
                print("PIG LATIN:", t.translate_sentence(sentence))
